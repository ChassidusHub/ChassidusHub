import type { EntityDataByType, EntityType } from '@rebbehub/model';

/** One valid example of every entity type, typed by entities.ts and checked against the JSON Schemas. */
export const EXAMPLES: { [T in EntityType]: EntityDataByType[T] } = {
  set: { name: { he: 'לקוטי שיחות', en: 'Likkutei Sichos' }, slug: 'likkutei-sichos', policy: 'moderated', keepers: ['u-shmuly'] },
  author: { name: { he: 'הרבי', en: 'The Rebbe' }, kind: 'rebbe', rebbe: 7, slug: 'the-rebbe', born: '5662-01-11', passed: '5754-10-03' },
  work: {
    title: { he: 'לקוטי שיחות', en: 'Likkutei Sichos' },
    slug: 'likkutei-sichos',
    authors: ['rh-00000001'],
    genre: 'sichos',
    levels: ['volume', 'parsha', 'sicha'],
    sets: ['rh-00000000'],
    externalIds: { 'sichos-kodesh-work': 'likkutei-sichos' },
    sourceCopies: [{ source: 'chabadlibrary', sourceId: '123', kind: 'text', licence: 'free-to-read' }],
  },
  unit: {
    work: 'rh-00000002',
    position: [
      { level: 'volume', value: '12' },
      { level: 'parsha', value: 'bereishis', label: { he: 'בראשית' } },
      { level: 'sicha', value: '3' },
    ],
    order: 'V',
    label: { he: 'חלק יב, בראשית, שיחה ג', en: 'Vol. 12, Bereishis, sicha 3' },
    date: '5736-07',
    events: ['rh-00000003'],
    editions: [{ source: 'mafteiach', sourceId: 'ls-12-3', kind: 'pdf', licence: 'facts-and-links', url: 'https://example.org/ls12.pdf' }],
    body: {
      profile: 'sefaria',
      versions: [
        {
          id: 'he',
          language: 'he',
          title: 'Kehot',
          credit: 'Sefaria: Kehot',
          licence: 'cc-by-nc',
          segments: [
            {
              id: '1',
              kind: 'section',
              n: 1,
              text: [{ text: 'פרק א' }],
              children: [
                { id: '1.1', kind: 'verse', n: 1, text: [{ text: 'בראשית', marks: ['b'] }, { text: ' ברא' }, { note: 'n1' }, { marker: '[ב.]' }, { br: true }, { text: 'עיין', href: 'rh-00000005' }] },
              ],
            },
          ],
          notes: [{ id: 'n1', kind: 'note', n: 1, text: [{ text: 'הערה' }] }],
        },
      ],
    },
  },
  event: { kind: 'farbrengen', title: { he: 'יו״ד שבט תשמ״ב', en: 'Yud Shvat 5742' }, date: '5742-05-10', occasion: 'yud-shvat', externalIds: { 'mafteiach-occasion': '4567' } },
  publication: {
    kind: 'teshura',
    title: { he: 'תשורה משמחת הנישואין' },
    date: '5784-03-15',
    simcha: { kind: 'wedding', families: ['כהן', 'לוי'], date: '5784-03-15', place: 'Crown Heights' },
    identifiers: { hebrewbooks: '14063' },
    pageCount: 64,
  },
  scan: { publication: 'rh-00000004', file: 'a'.repeat(64), completeness: 'complete', preferred: true, pageLabels: [{ pdfPage: 5, printed: 'א' }] },
  'contents-map': { publication: 'rh-00000004', pages: { from: 12, to: 15, scheme: 'printed' }, unit: 'rh-00000005' },
  'text-layer': { scan: 'rh-00000006', kind: 'machine-ocr', engine: { name: 'tesseract-heb', version: '5.3.4' }, language: 'he' },
  'text-page': {
    layer: 'rh-00000007',
    page: 3,
    lines: [
      { id: 'a', text: 'בס״ד', box: [0.45, 0.02, 0.1, 0.02] },
      { id: 'b', text: 'ב״ה, ה׳ תשרי, תש״כ', proofread: 1 },
    ],
    proofread: 0,
  },
  text: { kind: 'edition', unit: 'rh-00000005', publication: 'rh-00000004', language: 'he' },
  segment: { text: 'rh-00000008', order: 'V', kind: 'paragraph', content: 'במענה על מכתבו...', proofread: 0, origin: { by: 'ocr:tesseract-heb@5.3.4' } },
  recording: {
    event: 'rh-00000003',
    title: { he: 'התוועדות יו״ד שבט תשמ״ב — חלק א', en: 'Yud Shvat 5742 farbrengen, part 1' },
    file: 'b'.repeat(64),
    durationMs: 3_600_000,
    part: 1,
    language: 'yi',
    videos: [{ provider: 'jem', url: 'https://www.chabad.org/multimedia/video', startMs: 120_000 }],
  },
  alignment: { recording: 'rh-00000009', text: 'rh-00000008', granularity: 'paragraph' },
  'alignment-span': { alignment: 'rh-0000000a', segment: 'rh-0000000b', startMs: 10_000, endMs: 42_000, locked: true },
  relation: { kind: 'reproduces', from: 'rh-00000004', to: 'rh-00000005', origin: { by: 'crosslink:v1' } },
  person: { name: { he: 'ר׳ חיים מרדכי אייזיק חודקוב' }, aliases: ['Rabbi Hodakov'] },
  place: { name: { he: '770', en: '770 Eastern Parkway' }, kind: 'building', geo: { lat: 40.669, lon: -73.942 } },
  topic: { name: { he: 'אהבת ישראל', en: 'Ahavas Yisrael' } },
  source: { key: 'hebrewbooks', name: { he: 'היברו בוקס', en: 'HebrewBooks' }, url: 'https://hebrewbooks.org', licence: 'site-terms' },
  schema: { entityType: 'maaneh', label: { he: 'מענה', en: 'Maaneh' }, jsonSchema: { type: 'object' }, version: 1 },
};
